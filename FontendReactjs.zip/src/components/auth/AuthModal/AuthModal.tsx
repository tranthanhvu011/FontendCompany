import { useState, useEffect, useCallback, useRef } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { useUI } from '@/contexts/UIContext'
import { useAuth } from '@/contexts/AuthContext'
import { authService } from '@/services/authService'
import { FiX, FiEye, FiEyeOff, FiMail, FiSend } from 'react-icons/fi'
import {
    loginSchema, registerSchema, forgotSchema,
    type LoginFormData, type RegisterFormData, type ForgotFormData
} from '@/utils/validations'
import styles from './AuthModal.module.css'

type AuthView = 'login' | 'register' | 'forgot'

const getOtpCooldownKey = (email: string) => `otp_cooldown_end_${email.toLowerCase().trim()}`

export const AuthModal = () => {
    const { isLoginOpen, closeLogin } = useUI()
    const { checkUsername, checkEmail, sendOtp } = useAuth()
    const [view, setView] = useState<AuthView>('login')
    const [showPassword, setShowPassword] = useState(false)

    // OTP states
    const [showOtpSection, setShowOtpSection] = useState(false)
    const [otpCooldown, setOtpCooldown] = useState(0)
    const [isOtpSending, setIsOtpSending] = useState(false)
    const [otpSent, setOtpSent] = useState(false)

    // Debounce refs
    const usernameCheckTimeout = useRef<ReturnType<typeof setTimeout> | null>(null)
    const emailCheckTimeout = useRef<ReturnType<typeof setTimeout> | null>(null)

    // ========== React Hook Form Setup ==========
    const loginForm = useForm<LoginFormData>({
        resolver: zodResolver(loginSchema),
        mode: 'onBlur',
    })

    const registerForm = useForm<RegisterFormData>({
        resolver: zodResolver(registerSchema),
        mode: 'onBlur',
    })

    const forgotForm = useForm<ForgotFormData>({
        resolver: zodResolver(forgotSchema),
        mode: 'onBlur',
    })

    // ========== Reset khi đóng modal ==========
    useEffect(() => {
        if (!isLoginOpen) {
            setTimeout(() => {
                setView('login')
                setShowPassword(false)
                setShowOtpSection(false)
                setOtpSent(false)
                loginForm.reset()
                registerForm.reset()
                forgotForm.reset()
            }, 300)
        }
    }, [isLoginOpen])

    // Prevent body scroll
    useEffect(() => {
        if (isLoginOpen) {
            document.body.style.overflow = 'hidden'
        } else {
            document.body.style.overflow = ''
        }
        return () => { document.body.style.overflow = '' }
    }, [isLoginOpen])

    // ========== OTP Cooldown Logic ==========
    const initializeCooldown = useCallback((email: string) => {
        if (!email) return
        const key = getOtpCooldownKey(email)
        const savedEndTime = localStorage.getItem(key)
        if (savedEndTime) {
            const endTime = parseInt(savedEndTime, 10)
            const remainingSeconds = Math.ceil((endTime - Date.now()) / 1000)
            if (remainingSeconds > 0) {
                setOtpCooldown(remainingSeconds)
                setOtpSent(true)
            } else {
                localStorage.removeItem(key)
                setOtpCooldown(0)
            }
        }
    }, [])

    // Watch email field để show OTP section
    const watchedEmail = registerForm.watch('email')
    const isValidEmail = (email: string) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)

    useEffect(() => {
        if (watchedEmail && isValidEmail(watchedEmail)) {
            setShowOtpSection(true)
            initializeCooldown(watchedEmail)
        } else {
            setShowOtpSection(false)
        }
    }, [watchedEmail, initializeCooldown])

    // Countdown timer
    useEffect(() => {
        if (otpCooldown <= 0) return
        const timer = setInterval(() => {
            setOtpCooldown(prev => {
                if (prev <= 1) { clearInterval(timer); return 0 }
                return prev - 1
            })
        }, 1000)
        return () => clearInterval(timer)
    }, [otpCooldown])

    // ========== Debounce API Checks ==========
    const handleUsernameCheck = useCallback((username: string) => {
        if (usernameCheckTimeout.current) clearTimeout(usernameCheckTimeout.current)
        if (username.length >= 3) {
            usernameCheckTimeout.current = setTimeout(async () => {
                try {
                    const exists = await checkUsername(username)
                    if (exists) {
                        registerForm.setError('username', { message: 'Username đã tồn tại' })
                    } else {
                        registerForm.clearErrors('username')
                    }
                } catch {
                    registerForm.setError('username', { message: 'Không thể kiểm tra username' })
                }
            }, 500)
        }
    }, [checkUsername, registerForm])

    const handleEmailCheck = useCallback((email: string) => {
        if (emailCheckTimeout.current) clearTimeout(emailCheckTimeout.current)
        if (isValidEmail(email)) {
            emailCheckTimeout.current = setTimeout(async () => {
                try {
                    const exists = await checkEmail(email)
                    if (exists) {
                        registerForm.setError('email', { message: 'Email đã tồn tại' })
                    } else {
                        registerForm.clearErrors('email')
                    }
                } catch {
                    registerForm.setError('email', { message: 'Không thể kiểm tra email' })
                }
            }, 500)
        }
    }, [checkEmail, registerForm])

    // ========== Send OTP ==========
    const handleSendOtp = async () => {
        const email = registerForm.getValues('email')
        if (!email || otpCooldown > 0 || isOtpSending) return
        setIsOtpSending(true)
        try {
            await sendOtp(email)
            const cooldownDuration = 60
            const endTime = Date.now() + cooldownDuration * 1000
            localStorage.setItem(getOtpCooldownKey(email), endTime.toString())
            setOtpCooldown(cooldownDuration)
            setOtpSent(true)
        } catch (error) {
            console.log('❌ sendOtp failed:', error)
        } finally {
            setIsOtpSending(false)
        }
    }

    // ========== Submit Handlers ==========
    const onLoginSubmit = async (data: LoginFormData) => {
        try {
            await authService.login({ email: data.email, password: data.password })
            handleClose()
        } catch (error) {
            // interceptor hiện toast error
        }
    }

    const onRegisterSubmit = async (data: RegisterFormData) => {
        if (!otpSent) {
            registerForm.setError('otp', { message: 'Vui lòng gửi mã OTP trước' })
            return
        }
        try {
            await authService.register({
                username: data.username,
                email: data.email,
                password: data.password,
                otp: data.otp,
            })
            handleClose()
        } catch (error) {
            // interceptor hiện toast error
        }
    }

    const onForgotSubmit = async (data: ForgotFormData) => {
        try {
            console.log('Forgot password:', data.email)
            // TODO: call API forgot password
        } catch (error) {
            // interceptor hiện toast error
        }
    }

    // ========== Helpers ==========
    const handleClose = () => closeLogin()
    const handleBackdropClick = (e: React.MouseEvent) => {
        if (e.target === e.currentTarget) handleClose()
    }

    // ========== Animation Variants ==========
    const backdropVariants = {
        hidden: { opacity: 0 },
        visible: { opacity: 1 }
    }
    const modalVariants = {
        hidden: { opacity: 0, scale: 0.9, y: 20 },
        visible: {
            opacity: 1, scale: 1, y: 0,
            transition: { type: 'spring' as const, damping: 25, stiffness: 300 }
        },
        exit: { opacity: 0, scale: 0.9, y: 20, transition: { duration: 0.2 } }
    }
    const contentVariants = {
        hidden: { opacity: 0, x: 20 },
        visible: { opacity: 1, x: 0, transition: { delay: 0.1 } },
        exit: { opacity: 0, x: -20 }
    }

    // ========== RENDER ==========
    return (
        <AnimatePresence>
            {isLoginOpen && (
                <motion.div
                    className={styles.backdrop}
                    variants={backdropVariants}
                    initial="hidden"
                    animate="visible"
                    exit="hidden"
                    onClick={handleBackdropClick}
                >
                    <motion.div
                        className={styles.modal}
                        variants={modalVariants}
                        initial="hidden"
                        animate="visible"
                        exit="exit"
                        onClick={(e) => e.stopPropagation()}
                    >
                        <button className={styles.closeBtn} onClick={handleClose}>
                            <FiX />
                        </button>

                        <AnimatePresence mode="wait">
                            {/* ==================== LOGIN ==================== */}
                            {view === 'login' && (
                                <motion.div
                                    key="login"
                                    variants={contentVariants}
                                    initial="hidden"
                                    animate="visible"
                                    exit="exit"
                                    className={styles.content}
                                >
                                    <h2>Welcome Back, Get Login</h2>
                                    <p className={styles.subtitle}>
                                        Join your account. Don't have account?{' '}
                                        <button type="button" className={styles.linkBtn} onClick={() => setView('register')}>
                                            Create Account
                                        </button>
                                    </p>

                                    <form onSubmit={loginForm.handleSubmit(onLoginSubmit)}>
                                        <div className={styles.formGroup}>
                                            <label>Email</label>
                                            <div className={styles.inputWrapper}>
                                                <input
                                                    type="email"
                                                    placeholder="customer@demo.com"
                                                    {...loginForm.register('email')}
                                                />
                                            </div>
                                            {loginForm.formState.dirtyFields.email && loginForm.formState.errors.email && (
                                                <p className={styles.errorText}>{loginForm.formState.errors.email.message}</p>
                                            )}
                                        </div>

                                        <div className={styles.formGroup}>
                                            <label>Password</label>
                                            <div className={styles.inputWrapper}>
                                                <input
                                                    type={showPassword ? 'text' : 'password'}
                                                    placeholder="••••••••"
                                                    {...loginForm.register('password')}
                                                />
                                                <button
                                                    type="button"
                                                    className={styles.eyeBtn}
                                                    onClick={() => setShowPassword(!showPassword)}
                                                >
                                                    {showPassword ? <FiEyeOff /> : <FiEye />}
                                                </button>
                                            </div>
                                            {loginForm.formState.dirtyFields.password && loginForm.formState.errors.password && (
                                                <p className={styles.errorText}>{loginForm.formState.errors.password.message}</p>
                                            )}
                                        </div>

                                        <div className={styles.formOptions}>
                                            <label className={styles.checkbox}>
                                                <input type="checkbox" />
                                                <span className={styles.checkmark}></span>
                                                Remember me
                                            </label>
                                            <button type="button" className={styles.forgotLink} onClick={() => setView('forgot')}>
                                                Forgot Password?
                                            </button>
                                        </div>

                                        <button type="submit" className={styles.submitBtn}>
                                            Get Login
                                        </button>
                                    </form>
                                </motion.div>
                            )}

                            {/* ==================== REGISTER ==================== */}
                            {view === 'register' && (
                                <motion.div
                                    key="register"
                                    variants={contentVariants}
                                    initial="hidden"
                                    animate="visible"
                                    exit="exit"
                                    className={styles.content}
                                >
                                    <h2>Welcome Back, Get Login</h2>
                                    <p className={styles.subtitle}>
                                        Create your account. Already have account?{' '}
                                        <button type="button" className={styles.linkBtn} onClick={() => setView('login')}>
                                            Login here
                                        </button>
                                    </p>

                                    <form onSubmit={registerForm.handleSubmit(onRegisterSubmit)}>
                                        {/* Username */}
                                        <div className={styles.formGroup}>
                                            <label>Username</label>
                                            <div className={styles.inputWrapper}>
                                                <input
                                                    type="text"
                                                    placeholder="Nhập username"
                                                    {...registerForm.register('username', {
                                                        onChange: (e) => handleUsernameCheck(e.target.value),
                                                    })}
                                                />
                                                {!registerForm.formState.errors.username && registerForm.watch('username')?.length >= 3 && (
                                                    <span className={styles.inputSuccess}>✓</span>
                                                )}
                                            </div>
                                            {registerForm.formState.dirtyFields.username && registerForm.formState.errors.username && (
                                                <p className={styles.errorText}>{registerForm.formState.errors.username.message}</p>
                                            )}
                                        </div>

                                        {/* Email */}
                                        <div className={styles.formGroup}>
                                            <label>Email</label>
                                            <div className={styles.inputWrapper}>
                                                <input
                                                    type="email"
                                                    placeholder="your@email.com"
                                                    {...registerForm.register('email', {
                                                        onChange: (e) => handleEmailCheck(e.target.value),
                                                    })}
                                                />
                                                {!registerForm.formState.errors.email && isValidEmail(registerForm.watch('email') || '') && (
                                                    <span className={styles.inputSuccess}>✓</span>
                                                )}
                                                <FiMail className={styles.inputIcon} />
                                            </div>
                                            {registerForm.formState.dirtyFields.email && registerForm.formState.errors.email && (
                                                <p className={styles.errorText}>{registerForm.formState.errors.email.message}</p>
                                            )}
                                        </div>

                                        {/* OTP Section */}
                                        <AnimatePresence>
                                            {showOtpSection && (
                                                <motion.div
                                                    initial={{ opacity: 0, height: 0 }}
                                                    animate={{ opacity: 1, height: 'auto' }}
                                                    exit={{ opacity: 0, height: 0 }}
                                                    transition={{ duration: 0.3 }}
                                                    className={styles.otpSection}
                                                >
                                                    <div className={styles.formGroup}>
                                                        <label>Mã OTP</label>
                                                        <div className={styles.otpRow}>
                                                            <div className={styles.inputWrapper}>
                                                                <input
                                                                    type="text"
                                                                    placeholder="Nhập mã 6 số"
                                                                    maxLength={6}
                                                                    className={styles.otpInput}
                                                                    {...registerForm.register('otp', {
                                                                        onChange: (e) => {
                                                                            const value = e.target.value.replace(/\D/g, '').slice(0, 6)
                                                                            registerForm.setValue('otp', value)
                                                                        },
                                                                    })}
                                                                />
                                                            </div>
                                                            <button
                                                                type="button"
                                                                className={`${styles.sendOtpBtn} ${otpCooldown > 0 || isOtpSending ? styles.sendOtpBtnDisabled : ''}`}
                                                                onClick={handleSendOtp}
                                                                disabled={otpCooldown > 0 || isOtpSending}
                                                            >
                                                                {isOtpSending ? (
                                                                    <span className={styles.spinner}></span>
                                                                ) : otpCooldown > 0 ? (
                                                                    <>
                                                                        <FiSend />
                                                                        <span>({otpCooldown}s)</span>
                                                                    </>
                                                                ) : (
                                                                    <>
                                                                        <FiSend />
                                                                        <span>Gửi mã</span>
                                                                    </>
                                                                )}
                                                            </button>
                                                        </div>
                                                        {registerForm.formState.dirtyFields.otp && registerForm.formState.errors.otp && (
                                                            <p className={styles.errorText}>{registerForm.formState.errors.otp.message}</p>
                                                        )}
                                                        {otpSent && otpCooldown === 0 && (
                                                            <p className={styles.otpHint}>Bạn có thể gửi lại mã OTP</p>
                                                        )}
                                                        {otpCooldown > 0 && (
                                                            <p className={styles.otpHint}>Mã OTP đã được gửi đến email của bạn</p>
                                                        )}
                                                    </div>
                                                </motion.div>
                                            )}
                                        </AnimatePresence>

                                        {/* Password */}
                                        <div className={styles.formGroup}>
                                            <label>Password</label>
                                            <div className={styles.inputWrapper}>
                                                <input
                                                    type={showPassword ? 'text' : 'password'}
                                                    placeholder="••••••••"
                                                    {...registerForm.register('password')}
                                                />
                                                <button
                                                    type="button"
                                                    className={styles.eyeBtn}
                                                    onClick={() => setShowPassword(!showPassword)}
                                                >
                                                    {showPassword ? <FiEyeOff /> : <FiEye />}
                                                </button>
                                            </div>
                                            {registerForm.formState.dirtyFields.password && registerForm.formState.errors.password && (
                                                <p className={styles.errorText}>{registerForm.formState.errors.password.message}</p>
                                            )}
                                        </div>

                                        <button type="submit" className={styles.submitBtn}>
                                            Register
                                        </button>
                                    </form>
                                </motion.div>
                            )}

                            {/* ==================== FORGOT ==================== */}
                            {view === 'forgot' && (
                                <motion.div
                                    key="forgot"
                                    variants={contentVariants}
                                    initial="hidden"
                                    animate="visible"
                                    exit="exit"
                                    className={styles.content}
                                >
                                    <h2>Reset Your Password</h2>
                                    <p className={styles.subtitle}>
                                        We will send you a link to reset your password
                                    </p>

                                    <form onSubmit={forgotForm.handleSubmit(onForgotSubmit)}>
                                        <div className={styles.formGroup}>
                                            <label>Email</label>
                                            <div className={styles.inputWrapper}>
                                                <input
                                                    type="email"
                                                    placeholder="your@email.com"
                                                    {...forgotForm.register('email')}
                                                />
                                            </div>
                                            {forgotForm.formState.dirtyFields.email && forgotForm.formState.errors.email && (
                                                <p className={styles.errorText}>{forgotForm.formState.errors.email.message}</p>
                                            )}
                                        </div>

                                        <button type="submit" className={styles.submitBtn}>
                                            Reset Password
                                        </button>
                                    </form>

                                    <div className={styles.divider}>
                                        <span>Or</span>
                                    </div>

                                    <p className={styles.backToLogin}>
                                        Back to{' '}
                                        <button type="button" className={styles.linkBtn} onClick={() => setView('login')}>
                                            Login here
                                        </button>
                                    </p>
                                </motion.div>
                            )}
                        </AnimatePresence>
                    </motion.div>
                </motion.div>
            )}
        </AnimatePresence>
    )
}
