export { ProductDetailModal } from './ProductDetailModal/ProductDetailModal';
