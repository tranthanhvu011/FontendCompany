export { ProductDetail } from './ProductDetail';
