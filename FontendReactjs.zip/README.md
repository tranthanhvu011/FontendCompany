# ReactJS Vite Professional Base Template

A production-ready ReactJS starter template built with Vite, TypeScript, and modern best practices.

## 🚀 Features

- **⚡ Lightning Fast** - Powered by Vite for instant HMR and optimized builds
- **🎯 TypeScript** - Full type safety with TypeScript
- **🔐 Authentication** - Built-in authentication with Context API
- **🛣️ Routing** - React Router v6 with protected routes
- **🎨 Modern UI** - Responsive design with CSS Modules
- **📦 API Integration** - Axios client with interceptors
- **🔧 Well Structured** - Professional folder structure
- **✨ Icons** - React Icons library included
- **🎭 Mock Data** - Demo API for quick prototyping

## 📁 Project Structure

```
src/
├── assets/          # Static assets (images, fonts, etc.)
├── components/      # Reusable components
│   ├── common/      # Common UI components (Button, Input, Card, etc.)
│   └── layout/      # Layout components (Header, Footer, MainLayout)
├── contexts/        # React Context for state management
├── hooks/           # Custom React hooks
├── pages/           # Page components
│   ├── Home/        # Landing page
│   ├── Login/       # Authentication page
│   ├── Dashboard/   # Protected dashboard
│   ├── Profile/     # User profile page
│   └── NotFound/    # 404 page
├── routes/          # Routing configuration
├── services/        # API services and HTTP clients
├── styles/          # Global styles
├── types/           # TypeScript type definitions
├── utils/           # Utility functions
├── App.tsx          # Main App component
└── main.tsx         # Application entry point
```

## 🛠️ Installation

1. **Clone or use this template**

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Set up environment variables**
   ```bash
   cp .env.example .env
   ```

## 🏃 Running the Application

### Development Mode
```bash
npm run dev
```
The application will start at `http://localhost:5173`

### Build for Production
```bash
npm run build
```

### Preview Production Build
```bash
npm run preview
```

### Lint Code
```bash
npm run lint
```

## 🔑 Demo Credentials

To test the authentication flow, use:
- **Email:** demo@example.com
- **Password:** demo123

## 📚 Key Technologies

- **React 19** - UI library
- **Vite 7** - Build tool and dev server
- **TypeScript** - Type safety
- **React Router v6** - Client-side routing
- **Axios** - HTTP client
- **React Icons** - Icon library
- **CSS Modules** - Scoped styling

## 🎯 Available Routes

| Route | Access | Description |
|-------|--------|-------------|
| `/` | Public | Home/Landing page |
| `/login` | Public | Login page |
| `/dashboard` | Protected | User dashboard |
| `/profile` | Protected | User profile |
| `*` | Public | 404 Not Found page |

## 🔧 Configuration

### Path Aliases

The project uses `@/` as an alias for the `src/` directory:

```typescript
import { Button } from '@/components/common'
import { useAuth } from '@/contexts/AuthContext'
```

### API Configuration

Update the API URL in `.env`:
```
VITE_API_URL=http://localhost:3000/api
```

## 📦 Components Library

### Common Components

- **Button** - Customizable button with variants (primary, secondary, danger, success)
- **Input** - Form input with label, error, and helper text support
- **Card** - Container component with optional hover effect
- **Loading** - Animated loading spinner

### Layout Components

- **Header** - Navigation bar with authentication state
- **Footer** - Footer with links and social media
- **MainLayout** - Main layout wrapper combining Header and Footer

## 🎨 Styling Guide

The project uses CSS Modules with CSS variables for theming:

```css
/* Available CSS Variables */
--primary: #3b82f6
--secondary: #8b5cf6
--success: #10b981
--danger: #ef4444
--warning: #f59e0b

/* Spacing Scale */
--spacing-xs: 0.25rem
--spacing-sm: 0.5rem
--spacing-md: 1rem
--spacing-lg: 1.5rem
--spacing-xl: 2rem
--spacing-2xl: 3rem
```

## 🔐 Authentication Flow

The template includes a complete authentication system:

1. **Login** - Users authenticate via the Login page
2. **Context State** - Auth state is managed via Context API
3. **Protected Routes** - Certain routes require authentication
4. **Local Storage** - Tokens and user data persist in localStorage
5. **Auto-Redirect** - Unauthorized users are redirected to login

## 🌐 API Integration

### Using the API Client

```typescript
import { apiClient } from '@/services/apiClient'

// GET request
const data = await apiClient.get('/endpoint')

// POST request
const result = await apiClient.post('/endpoint', { data })

// PUT request
const updated = await apiClient.put('/endpoint', { data })

// DELETE request
await apiClient.delete('/endpoint')
```

### Mock Services

The template includes mock services for demonstration:
- `authService` - Login, register, logout
- `userService` - Get/update user profile

Replace these with real API calls when ready!

## 🚀 Deployment

### Build Optimization

The Vite build is optimized for production:
- Code splitting
- Tree shaking
- Minification
- Asset optimization

### Deploy to Netlify/Vercel

1. Build the project: `npm run build`
2. Deploy the `dist` folder
3. Configure environment variables in your hosting platform

## 📝 Best Practices

- ✅ Use TypeScript for type safety
- ✅ Keep components small and focused
- ✅ Use CSS Modules for component styling
- ✅ Implement proper error handling
- ✅ Add loading states for async operations
- ✅ Use path aliases for clean imports
- ✅ Follow the established folder structure

## 🤝 Contributing

Feel free to customize this template for your needs!

## 📄 License

This template is free to use and modify.

## 🎉 Getting Started

1. Install dependencies: `npm install`
2. Start dev server: `npm run dev`
3. Open browser: `http://localhost:5173`
4. Login with demo credentials
5. Start building your app!

---

**Happy Coding! 🚀**
#   F o n t e n d C o m p a n y  
 